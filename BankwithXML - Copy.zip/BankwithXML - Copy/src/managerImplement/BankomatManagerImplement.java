package managerImplement;

import managers.BankomatManager;
import atm.Bankomat;

import java.util.logging.Logger;

public class BankomatManagerImplement implements BankomatManager {

    Logger logger = Logger.getLogger("MyLog");
         public BankomatManagerImplement() {
    }

    @Override
    public synchronized boolean checkMoney(int amount, Bankomat bankomat) {
        if (!(bankomat.getBalance() > amount)) {

            logger.info("ATM doesn't work");

            return false;
        }
        return true;
    }

    @Override
    public synchronized void redueeBalance(int amount, Bankomat bankomat) {
             if (checkMoney(amount, bankomat)) {
                 logger.info("redue Banlance");
                 bankomat.setBalance(bankomat.getBalance() - amount);
             }

    }
}
