package enums;

public enum Currency {
    USD, AMD, EUR, RUB;
}
