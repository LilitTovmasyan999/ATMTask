package enums;

public enum CardBrand {
    VISA, MASTER, Express;
}
