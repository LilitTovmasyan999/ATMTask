package atm;

import banks.Bank;
import exceptions.ATMWorkErrorException;
import exceptions.LessMoneyException;
import managerImplement.BankManagerImplement;
import managerImplement.BankomatManagerImplement;

public class Bankomat {
    private int balance = 5000;
    private Bank bank;
    private BankManagerImplement bankManagerImplement;
    private BankomatManagerImplement bankomatManagerImplement;

    public Bankomat(BankManagerImplement bankManagerImplement, Bank bank, BankomatManagerImplement bankomatManagerImplement) {
        this.bankManagerImplement = bankManagerImplement;
        this.bank = bank;
        this.bankomatManagerImplement = bankomatManagerImplement;

    }




    public synchronized void withDraw(int amount, String cardNumber) {
        if (bankomatManagerImplement.checkMoney(amount,this)) {
            if (bank.checkAmount(amount, cardNumber)) {
                bankManagerImplement.BankManagerMethod();
                bankomatManagerImplement.redueeBalance(amount,this);
                System.out.println("Get your " + amount + "$");
            }
            else {
                try {
                    throw new LessMoneyException();
                } catch (LessMoneyException e) {
                    e.printStackTrace();
                }

            }
        }
        else {
            try {
                throw new ATMWorkErrorException();
            } catch (ATMWorkErrorException e) {
                e.printStackTrace();
            }
        }

    }
//    public Bankomat(int balance) {
//        this.balance = balance;
//    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }
}
