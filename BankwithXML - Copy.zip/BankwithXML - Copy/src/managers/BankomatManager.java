package managers;

import atm.Bankomat;

public interface BankomatManager {
    boolean checkMoney(int amount, Bankomat bankomat);
    void redueeBalance(int amount, Bankomat bankomat);
}
