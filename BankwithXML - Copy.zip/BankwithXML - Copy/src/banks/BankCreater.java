package banks;

public interface BankCreater {
     Bank getInstance();
}
